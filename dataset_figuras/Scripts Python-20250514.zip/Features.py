# -*- coding: utf-8 -*-
"""

Sistemas de Adquisición y Procesamiento de Señales
Facultad de Ingeniería - UNER

Procesamiento ML (Machine Learning):
Script ejemplificando la extracción de características temporales de las señales,
y su comparación.     

Autor: Albano Peñalva
Fecha: Febrero 2025

"""
import numpy as np
import pandas as pd
import seaborn as sns
import process_data
import matplotlib.pyplot as plt

#%% Lectura del dataset

FS = 500 # Frecuencia de muestre: 500Hz
T = 2    # Tiempo total de cada registro: 2 segundos

folder = 'dataset_figuras' # Carpeta donde se almacenan los .csv

#Procesamos los archivos para obtener el dataset junto con el diccionario de clases
x, y, z, classmap = process_data.process_data(FS, T, folder)
ts = 1 / FS                   # tiempo de muestreo
N = FS*T                      # número de muestras en cada regsitro

#%% Graficación

t = np.linspace(0, N * ts, N)   # vector de tiempos
# Se crea un arreglo de gráficas, con tres columnas de gráficas 
# (correspondientes a cada eje) y tantos renglones como gesto distintos.
fig, axes = plt.subplots(len(classmap), 3, figsize=(20, 20))
fig.subplots_adjust(hspace=0.5)

# Se recorren y grafican todos los registros
trial_num = 0
for gesture_name in classmap:                           # Se recorre cada gesto
    for capture in range(int(len(x))):                  # Se recorre cada renglón de las matrices
        if (x[capture, N] == gesture_name):             # Si en el último elemento se detecta la etiqueta correspondiente
            # Se grafica la señal en los tres ejes
            axes[gesture_name][0].plot(t, x[capture, 0:N], label="Trial {}".format(trial_num))
            axes[gesture_name][1].plot(t, y[capture, 0:N], label="Trial {}".format(trial_num))
            axes[gesture_name][2].plot(t, z[capture, 0:N], label="Trial {}".format(trial_num))
            trial_num = trial_num + 1

# Se le da formato a los ejes de cada gráfica
    axes[gesture_name][0].set_title(classmap[gesture_name] + " (Aceleración X)")
    axes[gesture_name][0].grid()
    axes[gesture_name][0].legend(fontsize=6, loc='upper right');
    axes[gesture_name][0].set_xlabel('Tiempo [s]', fontsize=10)
    axes[gesture_name][0].set_ylabel('Aceleración [G]', fontsize=10)
    axes[gesture_name][0].set_ylim(-6, 6)
    
    axes[gesture_name][1].set_title(classmap[gesture_name] + " (Aceleración Y)")
    axes[gesture_name][1].grid()
    axes[gesture_name][1].legend(fontsize=6, loc='upper right');
    axes[gesture_name][1].set_xlabel('Tiempo [s]', fontsize=10)
    axes[gesture_name][1].set_ylabel('Aceleración [G]', fontsize=10)
    axes[gesture_name][1].set_ylim(-6, 6)
    
    axes[gesture_name][2].set_title(classmap[gesture_name] + " (Aceleración Z)")
    axes[gesture_name][2].grid()
    axes[gesture_name][2].legend(fontsize=6, loc='upper right');
    axes[gesture_name][2].set_xlabel('Tiempo [s]', fontsize=10)
    axes[gesture_name][2].set_ylabel('Aceleración [G]', fontsize=10)
    axes[gesture_name][2].set_ylim(-6, 6)

plt.tight_layout()
plt.show()

#%% Extracción de parámetros temporales

# Lista de features
features_list = [
    'x_mean', 'y_mean', 'z_mean', 
    'x_max', 'y_max', 'z_max', 
    'x_min', 'y_min', 'z_min',
    'x_max_pos', 'y_max_pos', 'z_max_pos', 
    'x_min_pos', 'y_min_pos', 'z_min_pos', 
    'x_rms', 'y_rms', 'z_rms', 
    'x_0_cross', 'y_0_cross', 'z_0_cross',
    'x_en_above_0', 'y_en_above_0', 'z_en_above_0',
    'x_en_below_0', 'y_en_below_0', 'z_en_below_0',
    'gesture_name']

# Diccionario de features
fd = {v: i for i, v in enumerate(features_list)}

# Cáclulo de features
features = np.zeros([len(x), len(features_list)])                  
for capture in range(int(len(x))):                  # Se recorre cada renglón de las matrices
    # Cálculo del valor medio
    features[capture][fd.get('x_mean')] = np.mean(x[capture, 0:N])         
    features[capture][fd.get('y_mean')] = np.mean(y[capture, 0:N])         
    features[capture][fd.get('z_mean')] = np.mean(z[capture, 0:N])          
    # TODO: Cálculo del máximo
    features[capture][fd.get('x_max')] = 0  
    features[capture][fd.get('y_max')] = 0 
    features[capture][fd.get('z_max')] = 0        
    # TODO: Cálculo del mínimo
    features[capture][fd.get('x_min')] = 0 
    features[capture][fd.get('y_min')] = 0  
    features[capture][fd.get('z_min')] = 0
    # TODO: Cálculo de la posición del máximo
    features[capture][fd.get('x_max_pos')] = 0  
    features[capture][fd.get('y_max_pos')] = 0
    features[capture][fd.get('z_max_pos')] = 0     
    # TODO: Cálculo de la posición del mínimo
    features[capture][fd.get('x_min_pos')] = 0
    features[capture][fd.get('y_min_pos')] = 0
    features[capture][fd.get('z_min_pos')] = 0        
    # TODO: Cálculo del valor RMS
    features[capture][fd.get('x_rms')] = 0
    features[capture][fd.get('y_rms')] = 0
    features[capture][fd.get('z_rms')] = 0
    # TODO: Cálculo de los cruces por cero
    features[capture][fd.get('x_0_cross')] = 0
    features[capture][fd.get('y_0_cross')] = 0
    features[capture][fd.get('z_0_cross')] = 0 
    # TODO: Cálculo de la energía de la señal por encima de cero
    features[capture][fd.get('x_en_above_0')] = 0 
    features[capture][fd.get('y_en_above_0')] = 0
    features[capture][fd.get('z_en_above_0')] = 0
    # TODO: Cálculo de la energía de la señal por debajo de cero
    features[capture][fd.get('x_en_below_0')] = 0
    features[capture][fd.get('y_en_below_0')] = 0
    features[capture][fd.get('z_en_below_0')] = 0   
    
    # gesture_name
    features[capture][fd.get('gesture_name')] = z[capture, N]                     
    
#%% Graficación de matrices de correlación

# Creaciónd e un DataFrame de Pandas
df = pd.DataFrame(features, columns=features_list)

# Graficación de matrices de correlación por cada conjunto de features
sns.pairplot(df, vars=['x_mean', 'y_mean', 'z_mean'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_max', 'y_max', 'z_max'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_min', 'y_min', 'z_min'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_max_pos', 'y_max_pos', 'z_max_pos'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_min_pos', 'y_min_pos', 'z_min_pos'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_rms', 'y_rms', 'z_rms'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_0_cross', 'y_0_cross', 'z_0_cross'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_en_above_0', 'y_en_above_0', 'z_en_above_0'], hue='gesture_name', palette="deep")
sns.pairplot(df, vars=['x_en_below_0', 'y_en_below_0', 'z_en_below_0'], hue='gesture_name', palette="deep")
plt.plot()